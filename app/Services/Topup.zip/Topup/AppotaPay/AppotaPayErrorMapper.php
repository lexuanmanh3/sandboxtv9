<?php

namespace App\Services\Topup\AppotaPay;

use App\Enums\KetQuaNhaCungCap;

final class AppotaPayErrorMapper
{
    public function map(?string $code): KetQuaNhaCungCap
    {
        if ($code === '0') {
            return KetQuaNhaCungCap::SUCCESS;
        }

        // Các mã này không chứng minh được thuê bao chưa được nạp.
        if (in_array($code, ['34', '35', '99'], true)) {
            return KetQuaNhaCungCap::UNKNOWN_OR_PENDING;
        }

        return KetQuaNhaCungCap::DEFINITIVE_FAILURE;
    }
}
