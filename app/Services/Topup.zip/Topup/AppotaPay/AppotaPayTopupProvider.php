<?php

namespace App\Services\Topup\AppotaPay;

use App\Contracts\NhaCungCapTopupInterface;
use App\DTOs\KetQuaNhaCungCapDTO;
use App\DTOs\KetQuaSoDuDTO;
use App\DTOs\KetQuaThueBao;
use App\DTOs\YeuCauNapTienDTO;
use App\Enums\KetQuaNhaCungCap;
use App\Models\KetNoiNhaCungCap;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;
use RuntimeException;

final class AppotaPayTopupProvider implements NhaCungCapTopupInterface
{
    public function __construct(
        private KetNoiNhaCungCap $ketNoi,
        private AppotaPayJwt $jwt,
        private AppotaPaySignature $signature,
        private AppotaPayErrorMapper $errorMapper
    ) {
    }

    public function kiemTraThueBao(string $soDienThoai): KetQuaThueBao
    {
        $data = $this->get('/api/v1/service/topup/'.rawurlencode($soDienThoai).'/info')->json();
        return new KetQuaThueBao($soDienThoai, data_get($data, 'data.telco'), data_get($data, 'data.telcoServiceType'), $data);
    }

    public function layDanhSachSanPham(): Collection
    {
        $data = $this->get('/api/v2/service/topup/productCodes')->json();
        return collect($data['data'] ?? [])->flatMap(function ($group) {
            return collect($group['products'] ?? [])->map(fn ($product) => array_merge($product, ['telco' => $group['telco'] ?? null]));
        })->values();
    }

    public function layGoiDataTheoThueBao(string $soDienThoai, string $loaiThueBao): Collection
    {
        $data = $this->get('/api/v1/service/topup/'.rawurlencode($soDienThoai).'/products', ['telco_service_type' => strtolower($loaiThueBao)])->json();
        return collect($data['data'] ?? []);
    }

    public function napTien(YeuCauNapTienDTO $dto): KetQuaNhaCungCapDTO
    {
        $payload = [
            'partnerRefId' => $dto->partnerRefId,
            'telco' => strtolower($dto->nhaMang),
            'telcoServiceType' => strtolower($dto->loaiThueBao),
            'productCode' => $dto->maSanPhamNcc,
            'phoneNumber' => $dto->soDienThoai,
        ];
        $payload['signature'] = $this->signature->charging($payload, $this->secret());

        try {
            return $this->normalize($this->client()->post('/api/v2/service/topup/charging', $payload), true);
        } catch (ConnectionException $exception) {
            return new KetQuaNhaCungCapDTO(KetQuaNhaCungCap::UNKNOWN_OR_PENDING, null, 'Không xác định do lỗi kết nối');
        }
    }

    public function kiemTraTrangThai(string $partnerRefId): KetQuaNhaCungCapDTO
    {
        try {
            return $this->normalize($this->get('/api/v1/service/topup/transaction/'.rawurlencode($partnerRefId)), false);
        } catch (ConnectionException $exception) {
            return new KetQuaNhaCungCapDTO(KetQuaNhaCungCap::UNKNOWN_OR_PENDING, null, 'Không xác định do lỗi kết nối');
        }
    }

    public function kiemTraSoDu(): KetQuaSoDuDTO
    {
        throw new RuntimeException('Kết nối này chưa cấu hình endpoint kiểm tra số dư.');
    }

    private function normalize(Response $response, bool $charging): KetQuaNhaCungCapDTO
    {
        $data = (array) $response->json();
        if ($response->serverError() || !$response->successful() && $response->status() === 0) {
            return new KetQuaNhaCungCapDTO(KetQuaNhaCungCap::UNKNOWN_OR_PENDING, null, 'HTTP không xác định', httpStatus: $response->status(), duLieu: $data);
        }

        $code = isset($data['errorCode']) ? (string) $data['errorCode'] : null;
        $result = $code === null ? KetQuaNhaCungCap::UNKNOWN_OR_PENDING : $this->errorMapper->map($code);
        $validSignature = null;
        if (isset($data['transaction'])) {
            $validSignature = $charging
                ? $this->signature->verifyChargingResponse($data, $this->secret())
                : $this->signature->verifyStatusResponse($data, $this->secret());
            if (!$validSignature) {
                $result = KetQuaNhaCungCap::UNKNOWN_OR_PENDING;
            }
        }

        return new KetQuaNhaCungCapDTO(
            $result,
            $code,
            $data['message'] ?? null,
            data_get($data, 'transaction.appotapayTransId'),
            $validSignature,
            $data['signature'] ?? null,
            isset($data['account']['balance']) ? (string) $data['account']['balance'] : null,
            data_get($data, 'transaction.time'),
            $data,
            $response->status()
        );
    }

    private function get(string $path, array $query = []): Response
    {
        return $this->client()->get($path, $query);
    }

    private function client()
    {
        $token = $this->jwt->tao((string) $this->ketNoi->partner_code, (string) $this->ketNoi->api_key_ma_hoa, $this->secret());
        return Http::baseUrl(rtrim((string) ($this->ketNoi->base_url ?: $this->ketNoi->api_url), '/'))
            ->connectTimeout((int) $this->ketNoi->connect_timeout_seconds)
            ->timeout((int) $this->ketNoi->request_timeout_seconds)
            ->acceptJson()
            ->withHeaders(['X-APPOTAPAY-AUTH' => $token, 'Language' => 'vi']);
    }

    private function secret(): string
    {
        return (string) $this->ketNoi->secret_key_ma_hoa;
    }
}
